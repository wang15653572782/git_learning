﻿using static System.Windows.Forms.AxHost;

using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Net;

using System.Net.Sockets;

namespace WinFormsApp2
{
    public class communicate
    {
        static Socket clientSocket;

        public void Connect()

        {

            //将⽹络端点表⽰：IP地址&端⼝ ⽤Socket侦听绑定

            IPEndPoint ipep = new IPEndPoint(IPAddress.Parse("49.140.58.196"), 3001); //填写本地电脑的IP或者其他路由器能拼通的电脑的IP，如果是其他电脑IP，则需将ConsoleTestApplication_socketServer⼯程放在对方的电脑上运行，客户端侦听。

            clientSocket = new Socket(ipep.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //将Socket连接到服务器

            try

            {

                clientSocket.Connect(ipep);

            }

            catch

            {


                Console.WriteLine("服务未启动！");



            }
            //string getstr;
            //Console.WriteLine("连接成功");
            //string I_want_sent="hello world";
            //sendMessage(I_want_sent);
            //getstr=getMessage();
            //Console.WriteLine(getstr);
        }

        public string getMessage()
        {//接收服务器信息
            String outBufferStr;

            Byte[] outBuffer = new Byte[1024];

            Byte[] inBuffer = new Byte[1024];
            clientSocket.Receive(inBuffer, 1024, SocketFlags.None);//如果接收的消息为空，则阻塞当前循环 ；

            Console.WriteLine("服务端：");

            return Encoding.ASCII.GetString(inBuffer);

        }


        public void sendMessage(string sentstr)
        {
            String outBufferStr;

            Byte[] outBuffer = new Byte[1024];

            Byte[] inBuffer = new Byte[1024];
            outBufferStr = sentstr;

            outBuffer = Encoding.ASCII.GetBytes(outBufferStr);

            clientSocket.Send(outBuffer, outBuffer.Length, SocketFlags.None);

        }
    }
    class tool
    {
  
        static public string IP = null;
        static public void connect(Form2 a) {
            Form3 frm3 = new Form3(a.state, a.flag, a.Head);
            frm3.Owner = a.Owner;
            frm3.Show();
            a.Hide();
        } 
    }
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            communicate com = new communicate();
            com.Connect();
            //com.sendMessage("hello");
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}